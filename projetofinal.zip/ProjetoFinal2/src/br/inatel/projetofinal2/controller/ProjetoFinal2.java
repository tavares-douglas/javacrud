package br.inatel.projetofinal2.controller;

import br.inatel.projetofinal2.view.TelaMain;


public class ProjetoFinal2 {

    
    public static void main(String[] args) {
        
        TelaMain tm = new TelaMain();
        
        tm.setVisible(true);
        
    }

}
